import axios from "axios";
import React, { Component } from "react";
import { toast } from "react-toastify";
import { setUserSession } from "../utils/common";
import {  Link } from "react-router-dom";

export default class Login extends Component {
    constructor(props) {
        super(props)

        this.state = {
            email: '',
            password: '',
            isLoading:false
        }
    }


    handleSubmit = () => {
        const { email, password } = this.state
        if (!email) {
            toast.warn("Please enter email.")
        } else if (!password) {
            toast.warn("Please enter password.")
        } else {
            this.setState({isLoading:true})
            axios.post("http://localhost:4000/users/signin", {
                username: email,
                password: password
            }).then(response => {
                this.setState({isLoading:false})

                console.log('response >>>', response)
                 toast.success("User login successfully.")

            }).catch(error => {
                this.setState({isLoading:false,
                password:''})
                if (error?.response?.status === 400 || error?.response?.status === 401) {
                    toast.warn(error.response.data.message)
                }
                else {
                    toast.warn("Something went very wrong.  Please try again later.")
                }
                console.error('error >>>', error)
            });

        }
    }


    render() {
        const {isLoading} = this.state
        return (
            <form>

                <h3>Sign in</h3>

                <div className="form-group mt-2">
                    <label className="mt-1">Email</label>
                    <input type="email" className="form-control mt-1" placeholder="Enter email" onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            email: e.target.value
                        })
                    }} />
                </div>

                <div className="form-group mt-2">
                    <label className="mt-1">Password</label>
                    <input type="password" className="form-control mt-1" placeholder="Enter password" onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            password: e.target.value
                        })
                    }} />
                </div>

                <button type="submit" className="btn btn-dark btn-lg btn-block mt-2" onClick={(e) => {
                    e.preventDefault()
                    this.handleSubmit()
                }}>Sign in   {isLoading && (
                    <div
                      className="spinner-border text-primary ml-4"
                      style={{
                        width: "20px",
                        height: "20px",
                        marginRight: "5px",
                        textAlign: "center",
                      }}
                      role="status"
                    />
                  )}</button>
                <p className="forgot-password text-right">
                    No account yet? <Link to="/sign-up">Sign up for one here.</Link>
                </p>
            </form>
        );
    }
}