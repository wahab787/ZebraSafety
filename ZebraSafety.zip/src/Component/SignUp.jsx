import axios from "axios";
import React, { Component } from "react";
import { toast } from "react-toastify";
import {  Link } from "react-router-dom";

export default class SignUp extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             firstName:'',
             lastName:'',
             email:'',
             password:'',
             isLoading:false
        }
    }


    handleSubmit=()=>{
        const {firstName,lastName,email,password} = this.state

        if (!firstName) {
            toast.warn("Please enter first name.")
        } else if (!lastName) {
            toast.warn("Please enter last name.")
        } else if (!email) {
            toast.warn("Please enter email.")
        } else if (!password) {
            toast.warn("Please enter password.")
        } else{
            axios.post("http://localhost:4000/users/signup", {
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: password
        }).then(response => {
            this.setState({isLoading:false})
             toast.success("Register Successfully.")

        }).catch(error => {
            this.setState({isLoading:false,
            password:''})
            if (error?.response?.status === 400 || error?.response?.status === 401) {
                toast.warn(error.response.data.message)
            }
            else {
                toast.warn("Something went very wrong.  Please try again later.")
            }
            console.error('error >>>', error)
        });
        }
    }    
    render() {
        const {isLoading} = this.state
        return (
            <form>
                <h3>Register</h3>

                <div className="form-group">
                    <label>First name</label>
                    <input type="text" className="form-control" placeholder="First name" 
                    onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            firstName: e.target.value
                        })
                    }}/>
                </div>

                <div className="form-group">
                    <label>Last name</label>
                    <input type="text" className="form-control" placeholder="Last name" 
                     onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            lastName: e.target.value
                        })
                    }}/>
                </div>

                <div className="form-group">
                    <label>Email</label>
                    <input type="email" className="form-control" placeholder="Enter email" 
                    onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            email: e.target.value
                        })
                    }}/>
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password" 
                      onChange={(e) => {
                        e.preventDefault()
                        this.setState({
                            password: e.target.value
                        })
                    }}/>
                </div>

                <button type="submit" className="btn btn-dark btn-lg btn-block mt-2" onClick={(e)=>{
                    e.preventDefault()
                    this.handleSubmit()
                }}>Register {isLoading && (
                    <div
                      className="spinner-border text-primary ml-4"
                      style={{
                        width: "20px",
                        height: "20px",
                        marginRight: "5px",
                        textAlign: "center",
                      }}
                      role="status"
                    />
                  )}</button>
                <p className="forgot-password text-right">
                    Already registered <Link to="/sign-in">log in?</Link>
                </p>
            </form>
        );
    }
}